#include <string>

#include "catch.hpp"
#include "image.h"

#include "region_grower.hpp"

const std::string SEP = 
#if defined(_WIN32)
  "\\";
#else
  "/";
#endif

bool compareImages(std::string image1, std::string image2)
{
  Image<Pixel> input1 = readFromFile(image1);
  Image<Pixel> input2 = readFromFile(image2);

  // check size are the same
  if( (input1.width() != input2.width()) ||
      (input1.height() != input2.height()) )
    {
      return false;
    }
    
  // compare each pixel, stop on first difference
  bool ok = true;
  for (intmax_t i = 0; i < input1.width(); ++i)
    for (intmax_t j = 0; j < input1.height(); ++j) {
      if( input1(i,j) != input2(i,j) ){
	ok = false;
	break;
      }
    }
    
  if(!ok)
    {
      return false;
    }

  return true;
}



TEST_CASE( "Image compare", "[region_grower]" ) {
   // REQUIRE(compareImages("P3_2-1" + SEP + "test" + SEP + "hokie.png", "P3_2-1" + SEP + "test" + SEP + "hokie.png"));
   REQUIRE(compareImages("test" + SEP + "hokie.png", "test" + SEP + "hokie.png"));
}

